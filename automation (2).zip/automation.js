const { chromium } = require("playwright");
const path = require("path");
const fs = require("fs");

const CANCEL_URL =
  "https://dssp.karnataka.gov.in/bmsdbt_live/Canceltorunning?Length=0";
const LOGIN_URL = "https://dssp.karnataka.gov.in/bmsdbt_live/";
const beneficiaryIds = require("./data.js");
const { recognize } = require("tesseract.js");

// Credentials
const USERNAME = "hon_deo";
const PASSWORD = "Dssp@1234";

/**
 * Helper function to handle full login: fills credentials and waits for manual CAPTCHA
 */

/**
 * Solves numeric CAPTCHAs using Tesseract OCR
 */
async function solveAndSubmitCaptcha(page) {
  // 1. Locate CAPTCHA Image
  const captchaImg = page.locator("#ImgCaptcha");
  await captchaImg.waitFor({ state: "visible", timeout: 10000 });

  // 2. Capture raw image buffer
  const imageBuffer = await captchaImg.screenshot();

  // 3. OCR configured strictly for NUMBERS ONLY
  const {
    data: { text },
  } = await recognize(imageBuffer, "eng", {
    tessedit_char_whitelist: "0123456789", // Restricts recognition exclusively to numbers
  });

  // Strip any non-digit characters
  const numericCaptcha = text.replace(/[^0-9]/g, "").trim();
  console.log("Extracted Numeric CAPTCHA:", numericCaptcha);

  // 4. Fill CAPTCHA field
  const captchaInput = page.locator("#txtCaptcha");
  await captchaInput.fill(numericCaptcha);

  // 5. Submit form via #btnLogin
  const loginButton = page.locator("#btnLogin");
  await Promise.all([
    page
      .waitForNavigation({ waitUntil: "domcontentloaded", timeout: 15000 })
      .catch(() => {}),
    loginButton.click(),
  ]);
}

async function performLogin(page) {
  console.log("Navigating to Login Page...");

  await page.goto(LOGIN_URL, {
    waitUntil: "domcontentloaded",
    timeout: 60000,
  });

  // =========================
  // Fill Credentials
  // =========================
  const usernameField = page.locator(
    "#ctl00_ContentPlaceHolderMain_txtUserName, #txtUserName",
  );
  const passwordField = page.locator(
    '#ctl00_ContentPlaceHolderMain_txtPassword, input[type="password"]',
  );

  await usernameField.waitFor({ state: "visible", timeout: 30000 });
  await usernameField.fill(USERNAME);

  await passwordField.waitFor({ state: "visible", timeout: 30000 });
  await passwordField.fill(PASSWORD);

  console.log("Username and password filled.");

  // =========================
  // CAPTCHA / Login Attempts
  // =========================
  let attempts = 0;
  const maxAttempts = 5;
  let isLoggedIn = false;

  while (attempts < maxAttempts) {
    attempts++;
    console.log(
      `Attempting automated CAPTCHA solve (${attempts}/${maxAttempts})...`,
    );

    // Wait for navigation and submit simultaneously to prevent race conditions
    try {
      await Promise.all([
        page.waitForNavigation({
          waitUntil: "domcontentloaded",
          timeout: 15000,
        }),
        solveAndSubmitCaptcha(page),
      ]);
    } catch (err) {
      console.warn(
        `Navigation timeout or error on attempt ${attempts}. Checking login state...`,
      );
    }

    // Check if the current URL has moved away from the login page
    const currentUrl = page.url().toLowerCase();
    if (
      !currentUrl.includes("login") &&
      currentUrl !== LOGIN_URL.toLowerCase()
    ) {
      isLoggedIn = true;
      console.log("Login Successful!");
      break;
    }

    console.warn(
      `Login verification failed. Retrying (${attempts}/${maxAttempts})...`,
    );
  }

  // STOP execution if not logged in
  if (!isLoggedIn) {
    throw new Error(
      "Login failed after max attempts. Stopping script to prevent errors on target page.",
    );
  }

  // =========================
  // Navigate to Target Page
  // =========================
  console.log("Navigating to target page...");

  await page.goto(CANCEL_URL, {
    waitUntil: "domcontentloaded",
    timeout: 60000,
  });
}

/**
 * Helper function to check if the session expired or redirected back to login
 */
async function isLoggedOut(page) {
  const currentUrl = page.url().toLowerCase();
  if (currentUrl.includes("login") || currentUrl === LOGIN_URL.toLowerCase()) {
    return true;
  }
  // Optional check if login form exists on current page
  const usernameField = page.locator(
    "#ctl00_ContentPlaceHolderMain_txtUserName, #txtUserName",
  );
  return await usernameField.isVisible().catch(() => false);
}

(async () => {
  let browser;
  let context;
  let page;

  try {
    // ---------------------------------------------------------
    // 1. Initial Launch / Connection Setup
    // ---------------------------------------------------------
    try {
      browser = await chromium.connectOverCDP("http://127.0.0.1:9222");
      context = browser.contexts()[0];
      if (!context) throw new Error("No context found on port 9222.");

      console.log("Connected to existing Chrome (Port 9222).");
      page = await context.newPage();
      await page.goto(CANCEL_URL, {
        waitUntil: "domcontentloaded",
        timeout: 60000,
      });

      // Check if existing Chrome session was actually logged in
      if (await isLoggedOut(page)) {
        console.log("Session expired on CDP instance. Initiating login...");
        await performLogin(page);
      }
    } catch (connectionErr) {
      console.log("CDP Connection failed. Launching new browser...");
      context = await chromium.launchPersistentContext("", {
        headless: false,
        channel: "chrome",
        args: ["--start-maximized"],
      });

      page = context.pages()[0] || (await context.newPage());
      await performLogin(page);
    }

    await page.bringToFront();
    await page.waitForTimeout(2000);

    // ---------------------------------------------------------
    // 2. Process Beneficiary IDs with Auto-Relogin Recovery
    // ---------------------------------------------------------
    const results = [];

    for (let i = 0; i < beneficiaryIds.length; i++) {
      const id = beneficiaryIds[i];
      console.log("----------------------------------------");
      console.log(
        `[${i + 1}/${beneficiaryIds.length}] Processing Beneficiary ID: ${id}`,
      );

      // Check if session timed out prior to starting next ID
      if (await isLoggedOut(page)) {
        console.warn("Session expired detected! Triggering relogin...");
        await performLogin(page);
      }

      try {
        // Target visible text input
        const beneficiaryInput = page
          .locator('input[type="text"]:visible')
          .first();
        await beneficiaryInput.waitFor({ state: "visible", timeout: 10000 });

        // Clear input and enter ID
        await beneficiaryInput.click();
        await beneficiaryInput.press("Control+A");
        await beneficiaryInput.press("Backspace");
        await beneficiaryInput.fill(String(id));

        // Click Search
        const searchButton = page
          .locator(
            'button:has-text("Search"), input[type="submit"][value*="Search"]',
          )
          .first();
        await searchButton.waitFor({ state: "visible", timeout: 5000 });

        await Promise.all([
          page.waitForLoadState("networkidle").catch(() => {}),
          searchButton.click(),
        ]);

        // Post-search session check
        if (await isLoggedOut(page)) {
          console.warn(
            "Logged out right after search! Re-logging and retrying ID:",
            id,
          );
          await performLogin(page);
          i--; // Retry current ID
          continue;
        }

        // Locate result table
        const table = page.locator("table:visible").last();

        try {
          await table.waitFor({ state: "visible", timeout: 8000 });
        } catch {
          console.log("No result table found for:", id);
          results.push({ beneficiaryId: id, status: "NO_RESULT", data: [] });
          continue;
        }

        // -------------------------------------------------------
        // Modal Popup Interactions & Form Submission
        // -------------------------------------------------------
        const changeStatusBtn = table
          .locator(
            'button:has-text("Change Status"), a:has-text("Change Status"), input[value*="Change Status"]',
          )
          .first();
        await changeStatusBtn.waitFor({ state: "visible", timeout: 5000 });
        await changeStatusBtn.click();

        // Target exact "Cancel" Radio Button
        const cancelRadioButton = page.locator(
          "#ctl00_ContentPlaceHolderMain_rblStatus_0",
        );
        await cancelRadioButton.waitFor({ state: "visible", timeout: 8000 });
        await cancelRadioButton.click();

        // Target exact Reason Dropdown
        const reasonDropdown = page.locator(
          "#ctl00_ContentPlaceHolderMain_ddlReason",
        );
        await reasonDropdown.waitFor({ state: "visible", timeout: 10000 });

        await page.waitForFunction(
          (selectId) => {
            const el = document.getElementById(selectId);
            return el && el.options && el.options.length > 1;
          },
          "ctl00_ContentPlaceHolderMain_ddlReason",
          { timeout: 10000 },
        );

        try {
          await reasonDropdown.selectOption({ label: "Income Increased" });
        } catch {
          await reasonDropdown.selectOption({ index: 3 });
        }

        // Enter Date
        const dateInput = page.locator(
          "#ctl00_ContentPlaceHolderMain_txtReasonDate",
        );
        await dateInput.waitFor({ state: "visible", timeout: 5000 });
        await dateInput.click();
        await dateInput.fill("13/09/2026");

        // Upload PDF File
        const fileInput = page.locator(
          "#ctl00_ContentPlaceHolderMain_uploadFile",
        );
        await fileInput.waitFor({ state: "attached", timeout: 5000 });
        const filePath = path.join(__dirname, "KACHERI ADESHA.pdf");
        await fileInput.setInputFiles(filePath);

        // Alert listener
        page.once("dialog", async (dialog) => {
          console.log("Alert popup message:", dialog.message());
          await dialog.accept();
        });

        // Save Button Click
        const saveButton = page.locator(
          "#ctl00_ContentPlaceHolderMain_btnSave",
        );
        await saveButton.waitFor({ state: "visible", timeout: 5000 });

        await Promise.all([
          page.waitForLoadState("networkidle").catch(() => {}),
          saveButton.click(),
        ]);

        // Extract table data
        const tableData = await table.evaluate((tbl) => {
          const rows = Array.from(tbl.querySelectorAll("tr"));
          return rows.map((row) => {
            const cells = Array.from(row.querySelectorAll("th, td"));
            return cells.map((cell) => cell.innerText.trim());
          });
        });

        results.push({
          beneficiaryId: id,
          status: "SUCCESS",
          data: tableData,
        });

        console.log("Successfully processed ID:", id);
        await page.waitForTimeout(3000);
      } catch (err) {
        console.error(`Error while processing ID ${id}:`, err.message);

        // Check if error was caused by session expiry
        if (await isLoggedOut(page)) {
          console.warn("Session expired during execution! Retrying ID:", id);
          await performLogin(page);
          i--; // Decrement index to re-process current ID seamlessly
        } else {
          results.push({
            beneficiaryId: id,
            status: "FAILED",
            error: err.message,
          });
        }
      }
    }

    // Save final output
    fs.writeFileSync("results.json", JSON.stringify(results, null, 2));
    console.log("All tasks completed. Results saved to results.json");
  } catch (error) {
    console.error("Fatal script error:", error);
  }
})();
